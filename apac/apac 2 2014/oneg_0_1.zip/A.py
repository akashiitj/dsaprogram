#!/usr/bin/env python
# coding: utf-8

#########################################################################
#########################################################################

"""
   File Name: gcj.py
      Author: Wan Ji
      E-mail: wanji@live.com
  Created on: Sat Apr 12 14:59:24 2014 CST
"""
DESCRIPTION = """
"""

import os
import sys
import argparse


def perr(msg):
    """ Print error message.
    """

    sys.stderr.write("%s" % msg)
    sys.stderr.flush()


def pinfo(msg):
    """ Print information message.
    """

    sys.stdout.write("%s" % msg)
    sys.stdout.flush()


def runcmd(cmd):
    """ Run command.
    """

    perr("%s\n" % cmd)
    os.system(cmd)


def getargs():
    """ Parse program arguments.
    """

    parser = argparse.ArgumentParser(description=DESCRIPTION,
                                     formatter_class=
                                     argparse.RawTextHelpFormatter)
    parser.add_argument('infile', type=str, help='input file')
    parser.add_argument('outfile', type=str, nargs='?', default=None,
                        help='output file')

    return parser.parse_args()


MOD = 1000000007
C = []


def possible(M, N):
    if M == 1:
        return 1

    if M == N:
        ret = 1
        for i in range(N):
            ret *= (i+1)
        return ret

    ret = 0
    for i in range(1, N - M + 2):
        ret += C[N][i] * possible(M-1, N-i)
    return ret


def possible2(M, N):
    poss = [[0 for i in range(N+1)] for j in range(M+1)]
    poss[1] = [0] + [1 for i in range(1, N+1)]
    if M == 1:
        return poss[1][N]
    for m in range(2, M+1):
        for n in range(m, N+1):
            for i in range(1, n - m + 2):
                poss[m][n] += C[n][i] * poss[m-1][n-i]
    return poss[m][n]


def solve(M, N):
    return possible2(M, N)


def init_C(N):
    global C
    C = [[0 for i in range(j+2)] for j in range(N+1)]
    C[1][0] = 1
    C[1][1] = 1

    for i in range(2, N+1):
        for j in range(i + 1):
            C[i][j] = C[i-1][j-1] + C[i-1][j]


def main(args):
    """ Main entry.
    """

    if None == args.outfile:
        outfile = sys.stdout
    else:
        outfile = open(args.outfile, "w")

    init_C(101)

    with open(args.infile) as infile:
        T = int(infile.readline())
        for i in range(1, T + 1):
            [M, N] = [int(x) for x in infile.readline().split()]
            outfile.write("Case #%d: %d\n" % (i, solve(M, N) % MOD))

    if None != args.outfile:
        outfile.close()

if __name__ == '__main__':
    main(getargs())
