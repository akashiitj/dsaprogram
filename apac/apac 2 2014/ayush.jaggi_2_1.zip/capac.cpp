#include<bits/stdc++.h>
using namespace std;
int arrr[1000005];
// inhortcuts for "common" data types in contests
typedef long long ll;
typedef vector < long long > vll;
typedef pair < int, int > pii;
typedef vector < int > vii;
#define fstio ios_base::sync_with_stdio(false); cin.tie(NULL)
/*Use like- 
rep(i,0,n - 1)
*/
template<class T> T pwr(T b, T p){T r=1,x=b;while(p){if(p&1)r*=x;x*=x;p=(p>>1);}return r;}
 
#define     inf             (0x7f7f7f7f)
 
ll modPow(ll a, ll x, ll p) {
    //calculates a^x mod p in logarithmic time.
    ll res = 1;
    while(x > 0) {
        if( x % 2 != 0) {
            res = (res * a) % p;
        }
        a = (a * a) % p;
        x /= 2;
    }

    return res;
}
 
ll t, n, u, v, m, q, r, ql, qr, k, l, s, x, y, w, h, c, a, b, z, K;
const int N = 1e5 + 500;
const bool JUDGE = true;
ll A[N];
bool cvr[40 * N];
bool seive[500];
vector < pair < long long, long long > > flsh;
int solve(ll n, int cvr) {
	for (int i = 0; i < flsh.size(); ++i) {
		if (cvr & (1 << i)) {
			n /= flsh[i].first;
		}
	}
	int rtrn = 0;
	while (n) {
		rtrn += (n % 10);
		n /= 10;
	}
	return seive[rtrn];
}
int main(){
	fstio;
        freopen("clrg.txt", "r", stdin);
        freopen("clrgout.txt", "w", stdout);
	cin >> t;
	for (int i = 1; i < 500; ++i) {
		seive[i] = true;
		for (int j = 2; j < i; ++j) {
			if (i % j == 0) seive[i] = false;
		}
	}
	for (int cn1 = 1; cn1 <= t; ++cn1) {
		cout << "Case #" << cn1 << ": ";
		memset(cvr, false, sizeof(cvr));
		cin >> n;
        ql = n;
		flsh.clear();
		if (n % 2 == 0) {
			pair < long long, long long > a = make_pair(1LL, 2LL);
            ql = n;
			while (n % 2 == 0) {
				n /= 2;
				a.first *= 2;
			}
			flsh.push_back(a);
		}
		for (ll i = 3; i * i <= ql; i += 2) {
			if (n % i == 0) {
				pair < long long, long long > a = make_pair(1LL, i);
				while (n % i == 0) {
					n /= i;
					a.first *= i;
				}
				flsh.push_back(a);
            }
		}
		if (n > 1) flsh.push_back(make_pair(n, n));
		for (int i = (1 << (flsh.size())) - 1; i >= 0; --i) {
			if (solve(ql, i)) cvr[i] = false;
			else {
				for (int j = 0; j < flsh.size(); ++j) {
					if (!(i & (1 << j))) cvr[i] |= (!cvr[i + (1 << j)]);
				}
			}
		}
		if (cvr[0]) {
			cout << "Laurence\n";
		}
		else cout << "Seymour\n";
	}
	return 0;
}