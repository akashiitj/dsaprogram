#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <iterator>
#include <cstring>
#include <string>
#include <bitset>
#include <cmath>
#include <map>
#include <queue>
#include <set>
#include <iomanip>
#include <list>
#include <deque>

#define reps(i,a,b) for (int i=a;i<b;i++)
#define rep(i,b) for (int i=0;i<b;i++)
#define pb push_back
#define rz resize
#define vi vector<int>
#define vii vector<vector<int> >
#define mod 1000000007
#define oo 100000000

typedef unsigned long long ull;
typedef long long ll;
using namespace std;
double cap[401][80300];

int main()
{
    std::ios_base::sync_with_stdio(false);
    int cases,n,b,L;
    cin>>cases;
    int val[80300];
    int k=1;
    for (int i=1;i<=400;i++)
        for (int j=1;j<=i;j++)
            val[k++] = i;
    // for (int i=1;i<=10;i++)
    //     cout<<val[i]<<'\n';
    for (int t=1; t <= cases; t++)
    {
        memset(cap, 0, sizeof(cap));
        cin>>b>>L>>n;
        cap[1][1] = 750*b;

        int glevel = 0;
        for (int l=1;l<L;l++)
        {
            glevel += l;
            for (int glass = 1;glass<=glevel; glass++)
            {
                double flow = cap[l][glass] - 250;
                if (flow>0) flow/=3;
                else flow=0;
                if (flow) {
                int temp = val[glass];
                cap[l+1][glass] += flow;
                cap[l+1][glass+temp] += flow;
                cap[l+1][glass+temp+1] += flow;
                cap[l][glass] -= flow;
                }
            }
        }
        double ans = cap[L][n];
        if (ans > 250) ans = 250;
        cout<<"Case #"<<t<<": ";
        cout<<fixed<<setprecision(8)<<ans<<'\n';
    }
return 0;
}
