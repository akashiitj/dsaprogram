// Vishal Gupta IIIT-H
// novice_3
#include <bits/stdc++.h>
using namespace std;

#define sz(a) int((a).size())
#define all(c) c.begin(),c.end() //all elements of a container
#define rall(c) c.rbegin(),c.rend() 
#define INF		INT_MAX
#define FOR(i,a,b) 	for(int  i= (int )a ; i < (int )b ; ++i)
#define rep(i,n) 	FOR(i,0,n)
#define FORAB(i,a,b)      for(int i=(int)a; i<=b; i++)
#define PB push_back
#define MP make_pair
#define fill(a,b) memset(a,b,sizeof(a))
#define mod (int)(1e9 + 7)
#define F first
#define S second
#define asd(x) cout << "Here for " << #x << " :" <<x << endl;
#define asdf(x, y)  cout << "Here FOR " << #x << " :" << x << " " << #y  << " :" << y << endl;
typedef long long int LL;
typedef vector <int> VI;
typedef pair < int ,int > PII;
const int MAXN = 110;
int dp[MAXN][MAXN];
int a[MAXN],diff;

int solve(int left , int right){
	if(right<left) return 0;
 	int & ans = dp[left][right];
	if(ans==-1){
		if(right-left<=1) ans=right-left+1;		
		else{
		    ans=right-left+1;
			FORAB(i,left+1,right-1){
				if((a[i]-a[left]==a[right]-a[i]) && (a[i]-a[left]==diff)){
					if(solve(left+1,i-1) == 0 && solve(i+1, right-1)==0 ) ans=0; 
				}
				
				ans=min(ans, solve(left,i)+solve(i+1,right));
			}	
			ans=min(1+solve(left,right-1),ans);
			ans=min(1+solve(left+1,right),ans);
		}
	}
	return ans;
}
int main()
{
	  int testit, test;
	  cin >> test;
	  FORAB(testit,1 , test){
	  	int n,it=0,now;
	  	cin >> n >>diff ;		
	  	fill(dp,-1);
	  	rep(i,n) cin >> a[i];
	  	it=solve(0,n-1); 
	  	printf("Case #%d: %d\n",testit,it);
	  }

      return 0;
}

