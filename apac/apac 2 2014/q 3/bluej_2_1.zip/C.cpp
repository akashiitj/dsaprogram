#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int dp[110][110];
int arr[110];
int ca=1;
int main()
{
	//freopen("C-large.in","r",stdin);
	//freopen("C-large.out","w",stdout);
	int t;
	cin>>t;
	
	while(t--)
	{
		int n;
		cin>>n;
		int k;
		cin>>k;
		for(int i=0;i<n;i++)
		{
			cin>>arr[i];
			}
			
		dp[0][0]=1;
		dp[1][0]=2;
		dp[1][1]=1;
		dp[2][2]=1;
		dp[2][1]=2;
		if((arr[2]-arr[1])==k&&(arr[1]-arr[0])==k)
		{
			dp[2][0]=0;
			
			}
		else
			dp[2][0]=3;
			
			
		for(int i=3;i<n;i++)
		{
			dp[i][i]=1;
			dp[i][i-1]=2;
			for(int j=i-2;j>=0;j--)
			{
				dp[i][j]=min(dp[i-1][j+1]+2,dp[i-1][j]+1);
				dp[i][j]=min(dp[i][j],dp[i][j+1]+1);
				//if(arr[i]-arr[j]==2*k)
					for(int p=i;p>j;p--)
					{
						dp[i][j]=min(dp[i][j],dp[i][p]+dp[p-1][j]);
						}
					
					for(int p=i-1;p>=j+1;p--)
					{
						
						//int ca= p-1;// j+1 to p-1
							//int cb= p+1;  // p+1 to i-1
						
							int ch1,ch2;
							if(j==p-1)
								ch1=0;
							else
								ch1=dp[p-1][j+1];
							
							if(i==p+1)
								ch2=0;
							
							else
								ch2=dp[i-1][p+1];
								
						if(arr[i]-arr[p]==k&&arr[p]-arr[j]==k)
						{
							
								
							if(ch1==0&&ch2==0)
								dp[i][j]=0;
							else
								dp[i][j]=min(dp[i][j],ch1+ch2+3);
						}
						
						else
						{
							dp[i][j]=min(dp[i][j],ch1+ch2+3);
							
							}
						
					}
				
			
				
			
			}
			
			
		
		
		}
		
	/*	for(int i=0;i<n;i++)
		{
			for(int j=0;j<=i;j++)
			{
				cout<<dp[i][j]<<" ";
			}
			cout<<endl;
		}*/
		
			
	cout<<"Case #"<<ca<<": "<<dp[n-1][0]<<endl;
	memset(dp,0,sizeof(dp));
	ca++;
	}
	
	//fclose(stdin);
	//fclose(stdout);
}
