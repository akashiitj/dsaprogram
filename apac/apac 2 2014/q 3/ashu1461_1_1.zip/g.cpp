#include <bits/stdc++.h>
using namespace std;
#define asd(x)              cout<<__LINE__<<" :: "<<#x<< ": "<<x<<endl;
#define asdf(x, y)          cout<<__LINE__<<" :: "<<#x<< ": "<<x<<" | "<<#y<< ": "<<y<<endl;
#define CLR(a) memset(a, 0, sizeof(a))
#define SZ(V) (int )V.size()
#define ALL(V) V.begin(), V.end()
#define REP(i,a,b) for(int i=a;i<b;i++)
#define FORAB(i, a, b) REP(i,a,b+1)
#define PB push_back  
#define MP make_pair
#define F first
#define S second

typedef long long LL;
typedef pair<int,int> ii;
typedef vector <int> VI;

const double eps = 1e-7;

vector<ii> getpos(int ind,int L){
    LL l = L;
    REP(i,0,L){
        if((i*(i+1))/2 >= ind){ l = i;break;}
    }
    LL d = ind - ((l-1)*l)/2;
    LL val = (l*(l+1))/2 + d;
    vector<ii> result;
    result.PB(ii(ind,L+1));
    result.PB(ii(val,L+1));
    result.PB(ii(val+1,L+1));
    return result;
}

double dp[405][80405];
void update(int ind,int l){
    double volume = max(dp[l][ind]-250.0,0.0);
    dp[l][ind]=min(dp[l][ind],250.0);
    if(volume > eps){
        vector<ii> v = getpos(ind,l);
        REP(i,0,3){
            dp[v[i].S][v[i].F] += volume/3.0;
        }
    }
}

int main()
{
    LL test;
    cin >> test;
    REP(t,1,test+1){
        LL b,l,n;
        cin >> b >> l >> n;
        CLR(dp);
        dp[1][1] = b*750.0;
        REP(L,1,401){
            REP(n,1,(L*(L+1))/2+1){
                if(dp[L][n]-250.0>eps) update(n,L);
            }
        }
        printf("Case #%d: %.7lf\n",t,dp[l][n]);
    }
    return 0;
}
