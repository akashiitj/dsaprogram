// asdasdasda as dasd 
#include <bits/stdc++.h>
using namespace std;
#define REP(a,b,c) for(int a=b;a<c;a++)
#define asd(x)              cout<<__LINE__<<" :: "<<#x<< ": "<<x<<endl;
#define asdf(x, y)          cout<<__LINE__<<" :: "<<#x<< ": "<<x<<" | "<<#y<< ": "<<y<<endl;
typedef pair<int,int> ii;
typedef long long LL;

int dp[102][102], A[102], N, K;

int rec(int a, int b){
    if(b < a) return 0;
    if(b - a + 1 <= 2) return b-a+1;

    int &ret = dp[a][b];
    if(ret != -1) return ret;

    ret = b-a+1;
    ret = min(ret, 1 + rec(a+1, b));
    ret = min(ret, 1 + rec(a, b-1));

    REP(i, a+1, b){
        ret = min(ret, rec(a, i) + rec(i+1, b));
        if(A[i] - A[a] == K and A[b] - A[i] == K){
            if(rec(a+1, i-1) == 0 and rec(i+1, b-1) == 0) return ret = 0;
        }
    }
    return ret;
}


int solve(){
    cin >> N >> K;
    REP(i, 0, N) scanf("%d", &A[i]); 
    memset(dp, -1, sizeof dp);
    return rec(0, N-1);
}

int main(){
    int test;
    cin >> test;
    REP(t, 0, test){
        printf("Case #%d: %d\n", t+1, solve());
    }
    return 0;
}
