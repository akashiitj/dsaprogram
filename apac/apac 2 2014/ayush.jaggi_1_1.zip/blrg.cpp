#include<bits/stdc++.h>
using namespace std;
int arrr[1000005];
// inhortcuts for "common" data types in contests
#define ll long long int
#define VI vector<int>
#define VLL vector<long long int>
#define PQI priority_queue<int>
#define PQLL priority_queue<long long int>
#define VP vector<pair<int,int> >
#define II pair<int,int> 
#define ll long long int
#define mem(in,val) memset(in,val,sizeof(in)) 
#define mp make_pair 
#define sol first
#define Y second
#define pb push_back
#define rep(i,in,b) for(int i=in;i<b;i++)
/*Use like- 
rep(i,0,n - 1)
*/
template<class T> T pwr(T b, T p){T r=1,sol=b;while(p){if(p&1)r*=sol;sol*=sol;p=(p>>1);}return r;}
 
#define     inf             (0x7f7f7f7f)
 
ll modPow(ll a, ll sol, ll p) {
    //calculates a^sol mod p in logarithmic time.
    ll res = 1;
    while(sol > 0) {
        if( sol % 2 != 0) {
            res = (res * a) % p;
        }
        a = (a * a) % p;
        sol /= 2;
    }

    return res;
}
int sol[10001][10001];

int main()
{
    freopen("binl.txt","r",stdin);
    freopen("binlo.txt","w",stdout);
    int qp, qe, qt, cases, inp, factor, a, b, k, cc=1;
    long long ty, ty1, r, s, c;
    vector<int> p, e, t;
    bool flag;
    cin>>cases;
    while(cases--)
    {
        p.clear();
        e.clear();
        t.clear();
        memset(sol,0,sizeof(sol));
        cin>>qp>>qe>>qt;

        for(int i=0; i<qp; i++)
        {    cin>>inp;
        p.push_back(inp);
}
        for(int i=0; i<qe; i++){

            cin>>inp;
            e.push_back(inp);
        }

        for(int i=0; i<qt; i++){
            cin>>inp;
            t.push_back(inp);
}

        for(int i=0; i<qe; i++)
            for(int j=0; j<qt; j++)
            {
                factor=__gcd(e[i],t[j]);
                a=e[i]/factor,b=t[j]/factor;
                sol[a][b]=i+1;
            }
        cin>>k;
        cout<<"Case #"<<cc++<<":\n";
        while(k--)
        {
            flag=0;
            cin>>ty>>ty1;
            if(ty==1 && ty1==1)
            {
                cout<<"No"<<endl;
                continue;
            }
            for(int i=0; i<qp; i++)
                if(!flag)
                    for(int j=0; j<qe; j++)
                    {
                        r=ty*e[j];
                        s=ty1*p[i];
                        c=__gcd(r,s);
                        r/=c,s/=c;
                        if(r>10000 || s>10000)
                            continue;
                        if(sol[r][s] && sol[r][s]!=j+1)
                        {
                            flag=1;
                            break;
                        }
                    }
                else 
                    break;
            if(flag)
                cout<<"Yes"<<endl;
            else cout<<"No"<<endl;
        }
    }
    return 0;
}
