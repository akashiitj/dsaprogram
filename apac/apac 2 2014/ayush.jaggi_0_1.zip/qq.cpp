#include<bits/stdc++.h>
using namespace std;
int arrr[1000005];
// inhortcuts for "common" data types in contests
#define ll long long int
#define VI vector<int>
#define VLL vector<long long int>
#define PQI priority_queue<int>
#define PQLL priority_queue<long long int>
#define VP vector<pair<int,int> >
#define II pair<int,int> 
#define ll long long int
#define mem(in,val) memset(in,val,sizeof(in)) 
#define mp make_pair 
#define X first
#define Y second
#define pb push_back
#define rep(i,in,b) for(int i=in;i<b;i++)
/*Use like- 
rep(i,0,n - 1)
*/
template<class T> T pwr(T b, T p){T r=1,x=b;while(p){if(p&1)r*=x;x*=x;p=(p>>1);}return r;}
 
#define     inf             (0x7f7f7f7f)
 
ll modPow(ll a, ll x, ll p) {
    //calculates a^x mod p in logarithmic time.
    ll res = 1;
    while(x > 0) {
        if( x % 2 != 0) {
            res = (res * a) % p;
        }
        a = (a * a) % p;
        x /= 2;
    }

    return res;
}
const int N=700000;

int in[505][505][25];
int sol[25][505];
int t, n, m, k, x, y;
vector<int> v[505];


struct cmp{
    bool operator()(const pair<int, pair<int, int> > &p,const pair<int, pair<int, int> > &prq){
        return p.Y.X > prq.Y.X;
    }
};

void spath(int src, int time){
    VI dst(505, 999999999);
    int vstd[110000]={0};
    priority_queue<pair<int, pair<int, int> >, vector<pair<int, pair<int, int> > >, cmp> prq;
    prq.push(make_pair(src,make_pair(0, time)));
    dst[src]=0;
    while(!prq.empty()){
        int v1=prq.top().X;
        int hr = prq.top().Y.Y;
        prq.pop();
        if(vstd[v1]) continue;
        rep(i,0,v[v1].size()){
            int v2=v[v1][i], d2 = in[v1][v2][hr];
            if((dst[v2]>dst[v1]+d2)&&(!vstd[v2])){
                dst[v2]=dst[v1]+d2;
                prq.push(make_pair(v2,make_pair(dst[v2], (hr + d2) % 24)))  ;
            } 
        }
        vstd[v1]=1;        
    }

    for(int i = 2;i <= n;i++){
    	if(dst[i] == 999999999) sol[time][i] = -1;
    	else sol[time][i] = dst[i];
    }
}


int main(){
    freopen("ainl.txt","r",stdin);
    freopen("aout.txt","w",stdout);
    cin>>t;
	int w = 1;
	while(w <= t){
		memset(sol, 0, sizeof(sol));
		memset(in, 0, sizeof(in));
		
		scanf("%d %d %d", &n ,&m, &k);
		for(int i = 0;i <= n ;i++) v[i].clear();
		for(int i = 0;i < m;i++){
			cin>>x>>y;
			v[x].push_back(y);
			v[y].push_back(x);
			for(int j = 0;j < 24;j++){
				cin>>in[x][y][j];
				in[y][x][j] = in[x][y][j];
			}				
		}

		for(int i = 0;i < 24;i++){
			spath(1,i);
		}

		printf("Case #%d: ", w);
		for(int i = 0;i < k;i++){
			cin>>x>>y;
			cout<<sol[y][x]<<" ";
		}
        cout<<endl;
        w++;
	}
	
	return 0;
}