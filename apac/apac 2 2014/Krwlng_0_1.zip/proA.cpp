#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<cmath>
#include<algorithm>
#include<map>
#include<string>
using namespace std;

#define N 110
const long long MOD = 1000000007;
long long c[N][N], f[N][N];
int n, m;

long long extend_gcd(long long a,long long b,long long &x,long long &y)
{
    if(a==0&&b==0) return -1;
    if(b==0){x=1;y=0;return a;}
    long long d=extend_gcd(b,a%b,y,x);
    y-=a/b*x;
    return d;
}

void init() {
	int i, j, k;
	long long tmp, x, y;
	c[0][0]=1;
	for (i=1; i<N; ++i) {
		c[i][0]=1LL; c[i][1]=i;
		for (j=2; j<=i; ++j) {
			tmp=c[i][j-1];
			extend_gcd(j, MOD, x, y);
			x=(x%MOD+MOD)%MOD;
			tmp=tmp*(i-j+1)%MOD;
			tmp=tmp*x%MOD;
			c[i][j]=tmp;
		}
	}
	for (i=0; i<N; ++i) f[0][i]=f[1][i]=1;
	for (i=2; i<N; ++i) for (j=i; j<N; ++j) {
		f[i][j]=0LL;
		for (k=i-1; k<j; ++k) f[i][j]=(f[i][j]+f[i-1][k]*c[j][j-k])%MOD;
	}
}

int main() {
	init();
	int time; scanf("%d", &time);
	for (int i=1; i<=time; ++i) {
		scanf("%d%d", &n, &m);
		printf("Case #%d: ", i);
		cout << f[n][m] << endl;
	}
	return 0;
}
