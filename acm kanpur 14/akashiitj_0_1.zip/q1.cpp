#include<bits/stdc++.h>
using namespace std;

typedef long long  ll;
typedef unsigned long long  ull;



//cout<<fixed<<setprecision(6)<<ans<<"\n";

#define frmlty     int test_case;cin>>test_case;while(test_case--)

#define vi        vector<int>
#define vs        vector<string>
#define vll       vector<ll>
#define pii       pair<int,int>

#define msi       map<string,int>
#define msit      map<string,int>::iterator
#define pb        push_back
#define mp        make_pair

#define loop(i,a,b)      for(int i=a;i<b;i++)
#define rloop(i,a,b)     for(int i=b-1;i>=a;i--)

#define gcd(a,b)  __gcd(a,b)
#define maX(a,b)                     ( (a) > (b) ? (a) : (b))
#define miN(a,b)                     ( (a) < (b) ? (a) : (b))

#define le(x) scanf("%d",&x);
#define le2(x,y) scanf("%d%d",&x,&y);
#define lell(x) scanf("%lld",&x);
#define le2ll(x,y) scanf("%lld%lld",&x,&y);


#define piii pair<int,pii >
#define vpii vector< pii >
#define inf 10000000
#define mod 1000000007
#define fe first
#define se second






int dis[600][30];
priority_queue<piii,vector<piii>,greater<piii> > q;
vector<pii > adj[510];
int tim[2010][30],ans[5010];
void dijkstra(int dest,int start)
{
    for(int i=0; i<505; i++)for(int j=0; j<24; j++)dis[i][j]=inf;
    while(!q.empty())q.pop();
    dis[1][start]=0;
    q.push(mp(0,mp(1,start)));
    while(!q.empty())
    {
        int u = q.top().se.fe;
        int ucost = q.top().fe;
        int endtime = q.top().se.se;
        q.pop();
        if(u==dest)break;
        if(ucost>dis[u][endtime])continue;
        for(int i=0; i<adj[u].size(); i++)
        {
            int v=adj[u][i].fe;
            int edge = adj[u][i].se;
            int vcost = tim[edge][endtime];
            int vendtime = (endtime + vcost)%24;
            if(dis[v][vendtime]>dis[u][endtime]+vcost)
            {
                dis[v][vendtime]=dis[u][endtime]+vcost;
                q.push(mp(dis[v][vendtime],mp(v,vendtime)));
            }
        }

    }
}

int main()
{
    freopen ("1l.in","r",stdin);
    freopen ("o1l.out","w",stdout);

    int t;
    le(t);
    loop(test,1,t+1)
    {
        int n,m,k;
        le2(n,m);
        le(k);
        for(int i=0; i<5005; i++)adj[i].clear();
        for(int i=0; i<m; i++)
        {
            int a,b;
            le2(a,b);
            adj[a].pb(mp(b,i));
            adj[b].pb(mp(a,i));
            loop(j,0,24)
            {
                le(tim[i][j]);
            }
        }
        loop(h,1,k+1)
        {
            int a,b;
            le2(a,b);
            dijkstra(a,b);
            int res=inf;
            for(int i=0; i<24; i++)res = min(res,dis[a][i]);
            if(res>=inf)ans[h]=-1;
            else ans[h]=res;
        }
        printf("Case #%d: ",test);
        loop(h,1,k+1)
        {
            cout<<ans[h];
            if(h<k)cout<<' ';
            else cout<<endl;
        }

    }
    return 0;
}
