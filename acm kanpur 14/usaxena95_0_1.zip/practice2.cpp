/*
-----------------------------------------------------------------------------
Author :            ---------------------------------------------------------
    UTKAR$H $AXENA  ---------------------------------------------------------
    IIT INDORE      ---------------------------------------------------------
-----------------------------------------------------------------------------
*/
#include<bits/stdc++.h>
#include<iostream>
using namespace std;
#define fre 	freopen("0.in","r",stdin),freopen("0.out","w",stdout)
#define abs(x) ((x)>0?(x):-(x))
#define MOD 1000000007
#define lld signed long long int
#define pp pop_back()
#define ps(x) push_back(x)
#define mpa make_pair
#define pii pair<int,int>
#define fi first
#define se second
#define scan(x) scanf("%d",&x)
#define print(x) printf("%d\n",x)
#define scanll(x) scanf("%lld",&x)
#define printll(x) printf("%lld\n",x)
#define boost ios_base::sync_with_stdio(0)
vector<pair<int,vector<int> > > G[2*100000+5];
int visit[2*100000+5];
int sp[2*100000+5];
int N;
priority_queue<pair<int,pii > >Q;
int bfs(int D,int t){
	for(int i=1;i<=N;++i){
		visit[i] = 0;
		sp[i]=MOD;
	}
	while(not Q.empty()){
		Q.pop();
	}
	Q.push(mpa(0,mpa(1,t)));
	while(not Q.empty()){
		int cost = -Q.top().fi;
		int u = Q.top().se.fi;
		int tim = Q.top().se.se;
		Q.pop();
		if(visit[u])
			continue;
		visit[u]=1;
		if(u==D){
			return cost;
		}
		sp[u] = cost;
		for(int i=0;i<G[u].size();++i){
			int w = G[u][i].fi;
			Q.push(mpa(-cost-+G[u][i].se[tim],mpa(w,(tim+G[u][i].se[tim])%24)));
		}
	}
	return -1;
}
void solve(){
	int x,M,K,a,b,S,D;
	cin>>N>>M>>K;
	for(int i=1;i<=N;++i){
		G[i].clear();
	}
	vector<int>temp;
	for(int i=1;i<=M;++i){
		cin>>a>>b;
		temp.clear();
		for(int j=1;j<=24;++j){
			cin>>x;
			temp.ps(x);
		}
		G[a].ps(mpa(b,temp));
		G[b].ps(mpa(a,temp));
	}
	while(K--){
		cin>>D>>S;
		cout<<bfs(D,S)<<' ';
	}
}
int main()
{
	fre;
	int T;
	cin>>T;
	int i=0;
	while(T--){
		i++;
		printf("Case #%d: ",i);
		solve();
		cout<<endl;
	}
}
